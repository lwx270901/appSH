package dashboard.iot.bku;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import static dashboard.iot.bku.HomePage.getRandomString;

public class Kitchen extends AppCompatActivity {

    TextView txtTemp, txtHumi;
    Button btnBack;
    ToggleButton device1, device2, device3, device4;
    boolean[] enableBut = {true, true, true};
    MQTTHelperProcess mqttHelperProcess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchen);

        txtTemp = findViewById(R.id.KitTemp);
        txtHumi = findViewById(R.id.KitHumi);
        btnBack = findViewById(R.id.BackKit);
        device1 = findViewById(R.id.device1);
        device2 = findViewById(R.id.device2);
        device3 = findViewById(R.id.device3);
        device4 = findViewById(R.id.device4);
        String ran = getRandomString(6);

        mqttHelperProcess = new MQTTHelperProcess(ran, '3',getApplicationContext(), txtTemp, txtHumi, device1, device2, device3,device4,enableBut);
        mqttHelperProcess.startMQTT();
        mqttHelperProcess.setupScheduler();




        if(enableBut[0])
        {
            device1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
                    enableBut[0] = false;
                    if(isChecked){
                        Log.d(" mqtt ", " LED is checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/led", "3!1");
                    }
                    else {
                        Log .d(" mqtt ", " LED is not checked ");

                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/led", "3!0");

                    }
                }
            });
        }

//
//        if(enableBut[1])
//        {
//            device2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//
//
//                    if(isChecked)
//                    {
//                        Log.d(" mqtt ", " Button2 is checked ");
//                        mqttHelperProcess.sendDataMQTT("izayazuna/feeds/fan", "3!1");
//                    }
//                    else {
//                        Log .d(" mqtt ", " Button2 is not checked ");
//                        mqttHelperProcess.sendDataMQTT("izayazuna/feeds/fan", "3!0");
//                    }
//                }
//            });
//        }
//
////
//        if(enableBut[2])
//        {
//            device3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//
//                    if(isChecked)
//                    {
//                        Log.d(" mqtt ", " Button3 is checked ");
//                        mqttHelperProcess.sendDataMQTT("izayazuna/feeds/door", "3!1");
//                    }
//                    else {
//                        Log .d(" mqtt ", " Button3 is not checked ");
//                        mqttHelperProcess.sendDataMQTT("izayazuna/feeds/door", "3!0");
//                    }
//                }
//            });
//        }

//        device3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//
//                if(isChecked)
//                {
//                    Log.d(" mqtt ", " Button3 is checked ");
//                }
//                else {
//                    Log .d(" mqtt :", " Button3 is not checked ");
//                }
//            }
//        });



        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent switchActivityIntent = new Intent(Kitchen.this, HomePage.class);
                android.os.Process.killProcess(android.os.Process.myPid());
                startActivity(switchActivityIntent);
            }
        });


//        Bundle data = getIntent().getExtras();
//        if (data != null) {
//            String temperature = data.getString("temp");
//            //The key argument here must match that used in the other activity
//            txtTemp.setText(temperature + "*C");
//            String humidity = data.getString("humi");
//            //The key argument here must match that used in the other activity
//            txtHumi.setText(humidity + "%");
//
//            boolean led = data.getBoolean("led");
//            device1.setChecked(led);
//
//            boolean fan = data.getBoolean("fan");
//            device2.setChecked(fan);
//        }
    }
}
