package dashboard.iot.bku;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.view.View;
import android.widget.ToggleButton;

import static dashboard.iot.bku.HomePage.getRandomString;


public class LivingRoom extends AppCompatActivity {

    TextView txtTemp, txtHumi;
    Button btnBack;
    ToggleButton device1, device2, device3;
    boolean[] enableBut = {true, true, true};
    MQTTHelperProcess mqttHelperProcess;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_living_room);

        txtTemp = findViewById(R.id.LivTemp);
        txtHumi = findViewById(R.id.LivHumi);
        btnBack = findViewById(R.id.BackLiv);
        device1 = findViewById(R.id.device1);
        device2 = findViewById(R.id.device2);
        device3 = findViewById(R.id.device3);
        String ran = getRandomString(6);

        mqttHelperProcess = new MQTTHelperProcess(ran, '1',getApplicationContext(), txtTemp, txtHumi, device1, device2, device3,null, enableBut);
        mqttHelperProcess.startMQTT();
        mqttHelperProcess.setupScheduler();




        if(enableBut[0])
        {
            device1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    enableBut[0] = false;
                    if(isChecked){
                        Log.d(" mqtt ", " LED is checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/led", "1!1");
                    }
                    else {
                        Log .d(" mqtt ", " LED is not checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/led", "1!0");
                    }
                }
            });
        }

//
        if(enableBut[1])
        {
            device2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    enableBut[1] = false;
                    if(isChecked)
                    {
                        Log.d(" mqtt ", " Relay1 is checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/relay1", "1!1");
                    }
                    else {
                        Log .d(" mqtt ", " Relay1 is not checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/relay1", "1!0");
                    }
                }
            });
        }

//
        if(enableBut[2])
        {
            device3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    enableBut[2] = false;
                    if(isChecked)
                    {
                        Log.d(" mqtt ", " Relay2 is checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/relay2", "1!1");
                    }
                    else {
                        Log .d(" mqtt ", " Relay2 is not checked ");
                        mqttHelperProcess.sendDataMQTT("ProfesionalData/feeds/relay2", "1!0");
                    }
                }
            });
        }



        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mqttHelperProcess.delll();
                Intent switchActivityIntent = new Intent(LivingRoom.this, HomePage.class);
                android.os.Process.killProcess(android.os.Process.myPid());
                startActivity(switchActivityIntent);
            }
        });




//        Bundle data = getIntent().getExtras();
//        if (data != null) {
//            String temperature = data.getString("temp");
//            //The key argument here must match that used in the other activity
//            txtTemp.setText(temperature + "*C");
//            String humidity = data.getString("humi");
//            //The key argument here must match that used in the other activity
//            txtHumi.setText(humidity + "%");
//
////            boolean led = data.getBoolean("led");
////            device1.setChecked(led);
////
////            boolean fan = data.getBoolean("fan");
////            device2.setChecked(fan);
//        }






    }

}
