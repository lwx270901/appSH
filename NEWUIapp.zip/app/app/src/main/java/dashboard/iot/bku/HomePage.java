package dashboard.iot.bku;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class HomePage extends AppCompatActivity {
    Button btnLiv, btnBed, btnKit;
    ToggleButton device1, device2, device3;

    Intent intent;
//    MQTTHelper mqttHelper;
//    String[] temp = {"", "", ""};
//    String[] humi = {"", "", ""};
//    boolean[] fan;
//    boolean[] led;
//    boolean[] relay;

//    int nowAct = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
//        fan = new boolean[3];
//        led = new boolean[3];
//        relay = new boolean[3];

//

//        startMQTT();





        btnLiv = findViewById(R.id.Livingroom);
        btnLiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(1);
//                nowAct = 1;
            }
        });

        btnBed = findViewById(R.id.Bedroom);
        btnBed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(2);
//                nowAct = 2;
            }
        });

        btnKit = findViewById(R.id.Kitchen);
        btnKit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(3);
//                nowAct = 3;
            }
        });



    }



//    public class MQTTMessage{
//        public String topic;
//        public String mess;
//    }
//
//    int waiting_period = 3;
//    boolean send_message_agian = false ;
//    int resend_counter = 3;
//    List<MQTTMessage> list = new ArrayList<MQTTMessage>();
//
//
//    public void  sendDataMQTT(String topic, String value){
//        waiting_period = 3;
//        send_message_agian =false;
//        MQTTMessage aMessage = new MQTTMessage();
//        aMessage.topic = topic;
//        aMessage.mess = value;
//        list.add(aMessage);
//
//
//
//        MqttMessage msg = new MqttMessage();
//        msg.setId(1234);
//        msg.setQos(0);
//        msg.setRetained(true);
//
//        byte[] b = value.getBytes(Charset.forName("UTF-8"));
//        msg.setPayload(b);
//
//
//        try {
//            mqttHelper.mqttAndroidClient.publish(topic, msg);
//        }catch (MqttException e){
//
//        }
//
//    }
//
//
//
//
//    public void setupScheduler ()
//    {
//        Timer aTimer = new Timer();
//        TimerTask scheduler = new TimerTask() {
//            @Override
//            public void run() {
//                if( waiting_period > 0)
//                {
//                    waiting_period --;
//                    if( waiting_period == 0)
//                    {
//                        send_message_agian = true ;
//                        resend_counter --;
//                        if( resend_counter == 0)
//                        {
//                            waiting_period = 0;
//                            send_message_agian = false ;
//                            resend_counter = 3;
//                            list.clear();
//                            Log.d("mqtt", "size "+list.size()+" and delete message after 3 times resent");
//                        }
//                    }
//                    if(send_message_agian){
//                        if(!list.isEmpty())
//                        {
//                            Log.d("mqtt", "Resent data again from " + list.get(0).topic);
//                            sendDataMQTT(list.get(0).topic, list.get(0).mess);
//                            list.remove(0);
//                        }
//                    }
//                }
//            }
//
//
//        };
//        aTimer.schedule(scheduler, 0 , 1000);
//    }

    public static final String ALLOWED_CHARACTERS ="0123456789qwertyuiopasdfghjklzxcvbnm";

    public static String getRandomString(final int sizeOfRandomString)
    {
        final Random random=new Random();
        final StringBuilder sb=new StringBuilder(sizeOfRandomString);
        for(int i=0;i<sizeOfRandomString;++i)
            sb.append(ALLOWED_CHARACTERS.charAt(random.nextInt(ALLOWED_CHARACTERS.length())));
        return sb.toString();
    }



    public void openNewActivity(int select){
        switch (select){
            case 1:
                intent = new Intent(this, LivingRoom.class);
//                intent.putExtra("temp", temp[0]);
//                intent.putExtra("humi", humi[0]);
//                intent.putExtra("led", led[0]);
//                intent.putExtra("fan", fan[0]);
                break;
            case 2:
                intent = new Intent(this, Bedroom.class);
//                intent.putExtra("temp", temp[1]);
//                intent.putExtra("humi", humi[1]);
//                intent.putExtra("led", led[1]);
//                intent.putExtra("fan", fan[1]);
                break;
            case 3:
                intent = new Intent(this, Kitchen.class);
//                intent.putExtra("temp", temp[2]);
//                intent.putExtra("humi", humi[2]);
//                intent.putExtra("led", led[2]);
//                intent.putExtra("fan", fan[2]);
                break;
            default:
                break;
        }

        try {
            startActivity(intent);
        } catch (Exception e) {

        }
    }

    public static String decode(String message){
        String temp = "";
        for(int i = 2; i < message.length(); i++){
            temp += message.charAt(i);
        }
        return temp;
    }
//
//
//    public boolean checkButton(int btn)
//    {
//        if(btn == 0)
//        {
//            return false;
//        }
//        else
//        {
//            return true;
//        }
//    }
//
//    private void startMQTT() {
//        mqttHelper = new MQTTHelper(getApplicationContext(), "123456");
//
//        mqttHelper.setCallback(new MqttCallbackExtended() {
//            @Override
//            public void connectComplete(boolean reconnect, String serverURI) {
//                Log.d("mqtt", "Connection is successful");
//            }
//
//            @Override
//            public void connectionLost(Throwable cause) {
//
//            }
//
//            @Override
//            public void messageArrived(String topic, MqttMessage message) throws Exception {
//                Log.d("mqtt", "Received: " + message.toString());
//                if(topic.equals("izayazuna/feeds/temperature") ){
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        temp[0] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        temp[1] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        temp[2] = decode(message.toString());
//                    }
//                }
//                if(topic.equals("izayazuna/feeds/humidity")){
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        humi[0] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        humi[1] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        humi[2] = decode(message.toString());
//                    }
//                }
//
//                if(topic.equals("izayazuna/feeds/error_control"))
//                {
//                    waiting_period = 0;
//                    send_message_agian = false ;
//                    resend_counter = 3;
//                }
//                if(topic.equals("izayazuna/feeds/led"))
//                {
//                    int btn = Integer.parseInt(decode(message.toString()));
//                    if(message.toString().charAt(0) == '1')
//                    {
////                        led[0] = checkButton(btn);
//                        device1.setChecked(checkButton(btn));
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        led[2] = checkButton(btn);
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        led[2] = checkButton(btn);
//                    }
//                }
//                if(topic.equals("izayazuna/feeds/fan"))
//                {
//                    int btn = Integer.parseInt(decode(message.toString()));
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        device2.setChecked(checkButton(btn));
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        fan[1]=checkButton(btn);
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        fan[2]=checkButton(btn);
//                    }
//                }
//
//                openNewActivity(nowAct);
//            }
//
//            @Override
//            public void deliveryComplete(IMqttDeliveryToken token) {
//
//            }
//        });
//    }



}
