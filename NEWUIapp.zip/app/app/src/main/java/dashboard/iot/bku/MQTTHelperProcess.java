package dashboard.iot.bku;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static dashboard.iot.bku.HomePage.decode;

/**
 * Created by ADMIN on 3/21/2022.
 */

public class MQTTHelperProcess {

    MQTTHelper mqttHelper;
    String clientId;
    char Roomid;
    Context context;
    TextView temp, humi;
    ToggleButton dev1, dev2, dev3;
    boolean[] enableBut;
    public MQTTHelperProcess(String id, char room, Context con, TextView Roomtemp, TextView Roomhumi,
                             ToggleButton d1, ToggleButton d2, ToggleButton d3, boolean[] en)
    {
        clientId = id;
        Roomid = room;
        context = con;
        temp = Roomtemp;
        humi = Roomhumi;
        dev1 = d1;
        dev2 = d2;
        dev3 = d3;
        enableBut = en;
    }

    public class MQTTMessage{
        public String topic;
        public String mess;
    }

    int waiting_period = 3;
    boolean send_message_agian = false ;
    int resend_counter = 4;
    List<MQTTMessage> list = new ArrayList<MQTTMessage>();


    public void  sendDataMQTT(String topic, String value){
        waiting_period = 3;
        send_message_agian =false;
        MQTTMessage aMessage = new MQTTMessage();
        aMessage.topic = topic;
        aMessage.mess = value;
        list.add(aMessage);



        MqttMessage msg = new MqttMessage();
        msg.setId(1234);
        msg.setQos(0);
        msg.setRetained(true);

        byte[] b = value.getBytes(Charset.forName("UTF-8"));
        msg.setPayload(b);


        try {
            mqttHelper.mqttAndroidClient.publish(topic, msg);
        }catch (MqttException e){

        }

    }




    public void setupScheduler ()
    {
        Timer aTimer = new Timer();
        TimerTask scheduler = new TimerTask() {
            @Override
            public void run() {
                if( waiting_period > 0)
                {
                    waiting_period --;
                    if( waiting_period == 0)
                    {
                        send_message_agian = true ;
                        resend_counter --;
                        if( resend_counter == 0)
                        {
                            waiting_period = 0;
                            send_message_agian = false ;
                            resend_counter = 3;
                            //juju
                            for(int i = 0 ; i < 3;i++){
                                if(!enableBut[i])
                                {
                                    enableBut[i] = true;
                                }
                            }
                            list.clear();
                            Log.d("mqtt", "size "+list.size()+" and delete message after 3 times resent");
                        }
                    }
                    if(send_message_agian){
                        if(!list.isEmpty())
                        {
                            Log.d("mqtt", "Resent data again from " + list.get(0).topic);
                            sendDataMQTT(list.get(0).topic, list.get(0).mess);
                            list.remove(0);
                        }
                    }
                }
            }


        };
        aTimer.schedule(scheduler, 0 , 1000);
    }



    public boolean checkButton(int btn)
    {
        if(btn == 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }


//    public void delll()
//    {
//        mqttHelper = null;
//    }


    public void startMQTT() {
        mqttHelper = new MQTTHelper(context, clientId);

        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.d("mqtt", "Connection is successful");
            }

            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.d("mqtt", "Received: " + message.toString());
                if(topic.equals("izayazuna/feeds/temperature") ){
                    if(message.toString().charAt(0) == Roomid)
                    {
                        temp.setText(decode(message.toString()) + "°C");
                    }
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        temp[0] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        temp[1] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        temp[2] = decode(message.toString());
//                    }
                }
                if(topic.equals("izayazuna/feeds/humidity")){
                    if(message.toString().charAt(0) == Roomid)
                    {
                        humi.setText(decode(message.toString()) + "%");
                    }
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        humi[0] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        humi[1] = decode(message.toString());
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        humi[2] = decode(message.toString());
//                    }
                }

                if(topic.equals("izayazuna/feeds/error_control"))
                {
                    waiting_period = 0;
                    send_message_agian = false ;
                    resend_counter = 3;
                    for(int i = 0; i < 3;i++)
                    {
                        enableBut[i] = true;
                    }
                }
                if(topic.equals("izayazuna/feeds/led"))
                {
                    int btn = Integer.parseInt(decode(message.toString()));
                    if(message.toString().charAt(0) == Roomid)
                    {
                        dev1.setChecked(checkButton(btn));
                    }

//                    int btn = Integer.parseInt(decode(message.toString()));
//                    if(message.toString().charAt(0) == '1')
//                    {
////                        led[0] = checkButton(btn);
//                        device1.setChecked(checkButton(btn));
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        led[2] = checkButton(btn);
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        led[2] = checkButton(btn);
//                    }
                }
                if(topic.equals("izayazuna/feeds/fan"))
                {
                    int btn = Integer.parseInt(decode(message.toString()));
                    if(message.toString().charAt(0) == Roomid)
                    {
                        dev2.setChecked(checkButton(btn));
                    }
//                    int btn = Integer.parseInt(decode(message.toString()));
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        device2.setChecked(checkButton(btn));
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        fan[1]=checkButton(btn);
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        fan[2]=checkButton(btn);
//                    }
                }

                if(topic.equals("izayazuna/feeds/door"))
                {
                    int btn = Integer.parseInt(decode(message.toString()));
                    if(message.toString().charAt(0) == Roomid)
                    {
                        dev3.setChecked(checkButton(btn));
                    }
//                    int btn = Integer.parseInt(decode(message.toString()));
//                    if(message.toString().charAt(0) == '1')
//                    {
//                        device2.setChecked(checkButton(btn));
//                    }
//                    if(message.toString().charAt(0) == '2')
//                    {
//                        fan[1]=checkButton(btn);
//                    }
//                    if(message.toString().charAt(0) == '3')
//                    {
//                        fan[2]=checkButton(btn);
//                    }
                }

            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });
    }
}
